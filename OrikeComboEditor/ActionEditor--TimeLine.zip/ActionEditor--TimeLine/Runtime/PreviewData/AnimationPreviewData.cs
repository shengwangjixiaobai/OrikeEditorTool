using System;
using System.Collections.Generic;
using UnityEngine;


[Serializable]
public class AnimationPreviewData : BasePreviewData
{
    /// <summary>
    /// ��ǰ��ҪԤ���Ķ���
    /// </summary>
    public AnimationClip Animation;

    /// <summary>
    /// ��ǰ�����ڲ�ʱ��
    /// </summary>
    public float LocalTime;

    public AnimationPreviewData(
        AnimationClip animation,
        float localTime)
    {
        Animation = animation;
        LocalTime = localTime;
    }
}